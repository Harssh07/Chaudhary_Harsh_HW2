(function(){
	"use strict";	
	console.log("fired");
})();